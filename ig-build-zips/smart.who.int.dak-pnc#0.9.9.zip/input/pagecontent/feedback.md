
  <p>
    Feedback specific to this specification can provided through:
  </p>
  <ul>
    <li>Clicking on one of the Feedbacks link to the right of any section header</li>
    <li>Sending an email to <a href= "mailto:SMART_DAKS@who.int?subject = DAK Feedback">SMART_DAKS@who.int</a></li>
    <li>Creating an issue on GitHub <a href="{{ site.data.fhir.packageId | split: '.' | last | prepend: 'https://github.com/WorldHealthOrganization/' }}">{{ site.data.fhir.packageId | split: '.' | last }} repository</a></li>
  </ul>

