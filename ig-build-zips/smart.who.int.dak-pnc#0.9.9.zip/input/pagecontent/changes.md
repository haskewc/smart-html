### v1.0.0 release

This is the first release, therefore there are no changes to be mentioned here.